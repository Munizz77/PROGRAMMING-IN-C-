#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int x, y;

void divtest();
int checarDivisao(int x, int y);

int main() {
	
	srand(time(NULL));
	divtest();
 
    return 0;
}
void divtest(){
    int C;
    int Rdivisao;
    for (C = 0; C < 10; C++) {
    	x = rand() % 10;
    	y =  1 + (rand() % (10 - 1));
    	Rdivisao = checarDivisao(x, y);
    	
    	printf("Teste Nº %d\n", C+1);
	    printf("x %d\n", x);
	    printf("y %d\n", y);
	    printf("O valor [%d] é divísivel por [%d] %d ", x, y, Rdivisao);   
    }
}


int checarDivisao(int x, int y){
	if( x % y == 0){
		return 1;
	}else {
		return 0;
	}
	
}



